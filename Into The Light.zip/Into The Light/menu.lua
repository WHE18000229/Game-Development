--menu.lua

local composer = require("composer")

local scene = composer.newScene()

local function gotoGame()
	composer.removeScene("game")
	composer.gotoScene("game", fade)
end

local function helpScreen()
	composer.removeScene("help")
	composer.gotoScene("help", "slideUp")
end

local function quit()
	os.exit()
	timer.performWithDelay(1000, quit)
end

function scene:create(event)
	local sceneGroup = self.view
	local background = display.newImageRect( sceneGroup, "background.png", 800, 1400 )
	background.x = display.contentCenterX
	background.y = display.contentCenterY
	
	local title = display.newImageRect( sceneGroup, "main_menu_title.png", 739, 158 )
	title.x = display.contentCenterX
	title.y = 80
	
	local gameText = display.newImage(sceneGroup, "main_menu_start.png",display.contentCenterX, 75, nil, 200)
	gameText.x = display.contentCenterX
	gameText.y = 500
	
	local gameExit = display.newImage(sceneGroup, "main_menu_exit.png",display.contentCenterX, 75, nil, 146 )
	gameExit.x = display.contentCenterX
	gameExit.y = 700
	
	local gameHelp = display.newImage(sceneGroup, "message-24-help.png",display.contentCenterX, 56, 56)
	gameHelp.x = 50
	gameHelp.y = 1100
	
	gameText:addEventListener("tap", gotoGame)
	gameExit:addEventListener("tap", quit)
	gameHelp:addEventListener("tap", helpScreen)
	
end

-- show()
function scene:show( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is still off screen (but is about to come on screen)
 
    elseif ( phase == "did" ) then
        -- Code here runs when the scene is entirely on screen
 
    end
end
 
 
-- hide()
function scene:hide( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is on screen (but is about to go off screen)
 
    elseif ( phase == "did" ) then
        -- Code here runs immediately after the scene goes entirely off screen
 
    end
end
 
-- destroy()
function scene:destroy( event )
 
    local sceneGroup = self.view
    -- Code here runs prior to the removal of scene's view
 
end
 
 
-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------
 
return scene